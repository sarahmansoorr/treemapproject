"""Assignment 2: Trees for Treemap

=== CSC148 Fall 2020 ===
Diane Horton and David Liu
Department of Computer Science,
University of Toronto

=== Module Description ===
This module contains the basic tree interface required by the treemap
visualiser. You will both add to the abstract class, and complete a
concrete implementation of a subclass to represent files and folders on your
computer's file system.
"""

from __future__ import annotations
import os
# from abc import ABC
from random import randint
import math

from typing import Tuple, List, Optional, Dict


class AbstractTree:
    """A tree that is compatible with the treemap visualiser.

    This is an abstract class that should not be instantiated directly.

    You may NOT add any attributes, public or private, to this class.
    However, part of this assignment will involve you adding and implementing
    new public *methods* for this interface.

    === Public Attributes ===
    data_size: the total size of all leaves of this tree.
    colour: The RGB colour value of the root of this tree.
        Note: only the colours of leaves will influence what the user sees.

    === Private Attributes ===
    _root: the root value of this tree, or None if this tree is empty.
    _subtrees: the subtrees of this tree.
    _parent_tree: the parent tree of this tree; i.e., the tree that contains
        this tree
        as a subtree, or None if this tree is not part of a larger tree.

    === Representation Invariants ===
    - data_size >= 0
    - If _subtrees is not empty, then data_size is equal to the sum of the
      data_size of each subtree.
    - colour's elements are in the range 0-255.

    - If _root is None, then _subtrees is empty, _parent_tree is None, and
      data_size is 0.
      This setting of attributes represents an empty tree.
    - _subtrees IS allowed to contain empty subtrees (this makes deletion
      a bit easier).

    - if _parent_tree is not empty, then self is in _parent_tree._subtrees
    """
    data_size: int
    colour: (int, int, int)
    _root: Optional[object]
    _subtrees: List[AbstractTree]
    _parent_tree: Optional[AbstractTree]

    def __init__(self: AbstractTree, root: Optional[object],
                 subtrees: List[AbstractTree], data_size: int = 0) -> None:
        """Initialize a new AbstractTree.

        If <subtrees> is empty, <data_size> is used to initialize this tree's
        data_size. Otherwise, the <data_size> parameter is ignored, and this
        tree's data_size is computed from the data_sizes of the subtrees.

        If <subtrees> is not empty, <data_size> should not be specified.

        This method sets the _parent_tree attribute for each subtree to self.

        A random colour is chosen for this tree.

        Precondition: if <root> is None, then <subtrees> is empty.
        """
        self._root = root
        self._subtrees = subtrees
        self._parent_tree = None

        for subtree in self._subtrees:
            if subtree is not None:
                subtree._parent_tree = self

        self.colour = (randint(0, 255), randint(0, 255), randint(0, 255))

        if not self._subtrees:
            if not self.is_empty():
                self.data_size = data_size
            else:
                self.data_size = 0
        else:
            total_size = 0
            for subtree in self._subtrees:
                total_size += subtree.data_size
            self.data_size = total_size

    def is_empty(self: AbstractTree) -> bool:
        """Return True if this tree is empty."""
        return self._root is None

    def generate_treemap(self: AbstractTree, rect: Tuple[int, int, int, int]) \
            -> List[Tuple[Tuple[int, int, int, int], Tuple[int, int, int]]]:
        """Run the treemap algorithm on this tree and return the rectangles.

        Each returned tuple contains a pygame rectangle and a colour:
        ((x, y, width, height), (r, g, b)).

        One tuple should be returned per non-empty leaf in this tree.

        @type self: AbstractTree
        @type rect: (int, int, int, int)
            Input is in the pygame format: (x, y, width, height)
        @rtype: list[((int, int, int, int), (int, int, int))]
        """
        # Read the handout carefully to help get started identifying base cases,
        # and the outline of a recursive step.
        #
        # Programming tip: use "tuple unpacking assignment" to easily extract
        # coordinates of a rectangle, as follows.
        # x, y, width, height = rect

        x, y, width, height = rect

        rect_dict = {self: rect}

        # base case - tree is empty
        if self.is_empty():
            return []

        # if subtrees are empty and there is no parent tree
        if not self._subtrees and self.data_size > 0:
            return [(rect, self.colour)]

        treemap = []

        # display area's width is greater than its height
        if width > height:
            new_x = x
            for subtree in self._subtrees:
                temp_rec = (new_x, y, width, height)
                rec = self.width_greater_subtree(temp_rec, subtree)
                rect_dict[subtree] = rec
                # treemap.append((rec, subtree.colour))
                treemap += subtree.generate_treemap(rec)
                new_x = rec[0]

        # display area's height is greater than its width
        if height >= width:
            new_y = y
            for subtree in self._subtrees:
                temp_rec = (x, new_y, width, height)
                rec = self.height_greater_subtree(temp_rec, subtree)
                if subtree not in rect_dict:
                    rect_dict[subtree] = rec
                # treemap.append((rec, subtree.colour))
                treemap += subtree.generate_treemap(rec)
                new_y += rec[3]

        return treemap

    def width_greater_subtree(self: AbstractTree,
                              rect: Tuple[int, int, int, int],
                              subtree: AbstractTree) -> \
            Tuple[int, int, int, int]:
        """
        Return the rectangle of the subtree when the width is greater
        """
        x, y, width, height = rect
        if self.data_size == 0:
            portion = 0
        else:
            portion = subtree.data_size / self.data_size
        new_width = math.floor(portion * width)
        return x, y, new_width, height

    def height_greater_subtree(self: AbstractTree,
                               rect: Tuple[int, int, int, int],
                               subtree: AbstractTree) -> \
            Tuple[int, int, int, int]:
        """
        Return the rectangle of the subtree when the width is greater
        """
        x, y, width, height = rect
        if self.data_size == 0:
            portion = 0
        else:
            portion = subtree.data_size / self.data_size
        new_height = math.floor(portion * height)
        return x, y, width, new_height

    def get_separator(self: AbstractTree) -> str:
        """Return the string used to separate nodes in the string
        representation of a path from the tree root to a leaf.

        Used by the treemap visualiser to generate a string displaying
        the items from the root of the tree to the currently selected leaf.

        This should be overridden by each AbstractTree subclass, to customize
        how these items are separated for different data domains.
        """
        raise NotImplementedError

    def lst_leaves(self) -> List:
        """Return a list of the leaves in this tree. """
        if self.is_empty():
            return []
        if not self._subtrees:
            return [self]
        lst = []
        for subtree in self._subtrees:
            lst += subtree.lst_leaves()
        return lst

    def event_tree(self: AbstractTree, rect: Tuple[int, int, int, int],
                   coord: Tuple[int, int]) -> Optional[AbstractTree]:
        """Return the tree of the given <coord>."""
        rec_leaves = self.rect_leaves(rect)

        for rec in rec_leaves:
            if in_range(rect, coord):
                return rec_leaves[rec][0]

        return None

    def path_text(self) -> str:
        """Return the path for _render_text. """

    def right_rect_size(self: AbstractTree, rect: Tuple[int, int, int, int],
                        coord: Tuple[int, int]) -> None:
        """Delete <rect> and update data_size for tree. """
        if self.is_empty():
            return

        rec_leaves = self.rect_leaves(rect)

        for rec in rec_leaves:
            if in_range(rect, coord):
                for leaf in rec_leaves[rec]:
                    leaf.decrease(leaf.data_size)
                    leaf.data_size = 0
                    leaf.delete()

    def decrease(self, data_size: int) -> None:
        """Decrease the size of every parent tree of this leaf."""

        if self.is_empty() or self._parent_tree is None:
            return

        self._parent_tree.data_size -= data_size
        self._parent_tree.decrease(data_size)

    def delete(self: AbstractTree) -> None:
        """Delete the leaf from this tree."""
        if self._parent_tree is not None:
            self._parent_tree.data_size = 0
            if self in self._parent_tree._subtrees:
                self._parent_tree._subtrees.remove(self)
        self._root = None
        self.data_size = 0

    def rect_leaves(self: AbstractTree, rect: Tuple[int, int, int, int]) -> \
            Dict:
        """Return a dictionary of the rectangles as the keys and the leaves as
        the values. """

        leaves = self.lst_leaves()
        rec_leaves = {}
        treemap = self.generate_treemap(rect)
        n = len(treemap)
        for i in range(n):
            rec = treemap[i][0]
            if rec not in rec_leaves:
                rec_leaves[rec] = [leaves[i]]
            else:
                rec_leaves[rec].append(leaves[i])

        return rec_leaves

    def update_data_size(self: Optional[AbstractTree], data_size: int) -> \
            Optional[AbstractTree]:
        """Update the data_size of the trees. """
        new_data_size = math.ceil(0.01 * self.data_size)
        if data_size < 0:
            self.update_parent_size(data_size)

            if self.data_size <= 0 and self._parent_tree is not None:
                self._parent_tree._subtrees.remove(self)
                return None
            if self.data_size <= 0 and self._parent_tree is None:
                return None
        else:
            self.update_parent_size(new_data_size)
        return None

    def update_parent_size(self: AbstractTree, data_size: int) -> None:
        """Update the data_size of the tree and its parent_tree(s)."""
        if self._parent_tree is None:
            self.data_size += data_size
            return
        self.data_size += data_size
        self._parent_tree.update_parent_size(data_size)
        return

    def get_path(self: FileSystemTree) -> str:
        """Return the path of the leaf. """
        lst_path = self.lst_get_path()
        text = lst_path[-1]

        lst_path.reverse()

        for leaf in lst_path[1:]:
            text = text + self.get_separator() + leaf

        return text

    def lst_get_path(self) -> List:
        """Return a list of the leaves."""
        lst = []
        if self.is_empty():
            return lst
        if self._parent_tree is None:
            lst.append(self._root)
            return lst
        lst.append(self._root)
        lst = lst + self._parent_tree.lst_get_path()
        return lst


def in_range(rect: Tuple[int, int, int, int], coord: Tuple[int, int]) -> bool:
    """Return True if the rectangle is in the range of <coord>. False otherwise.
     """
    x, y, width, height = rect
    x_cor, y_cor = coord
    x_in_range = x_cor in range(x, x + width)
    y_in_range = y_cor in range(y, y + height)
    return x_in_range and y_in_range


class FileSystemTree(AbstractTree):
    """A tree representation of files and folders in a file system.

    The internal nodes represent folders, and the leaves represent regular
    files (e.g., PDF documents, movie files, Python source code files, etc.).

    The _root attribute stores the *name* of the folder or file, not its full
    path. E.g., store 'assignments', not '/Users/David/csc148/assignments'

    The data_size attribute for regular files as simply the size of the file,
    as reported by os.path.getsize.
    """

    def __init__(self: FileSystemTree, path: str) -> None:
        """Store the file tree structure contained in the given file or folder.

        Precondition: <path> is a valid path for this computer.
        """
        # Remember that you should recursively go through the file system
        # and create new FileSystemTree objects for each file and folder
        # encountered.
        #
        # Also remember to make good use of the superclass constructor!

        # base case
        # AbstractTree.__init__(self, root=self._root, subtrees=self._subtrees,
        #                      data_size=self.data_size)
        if not os.path.isdir(path):
            current_root = os.path.basename(path)
            current_data_size = os.path.getsize(path)
            AbstractTree.__init__(self, current_root, [], current_data_size)
        # recursive case
        else:
            current_subtrees = []
            path_lst = os.listdir(path)
            current_root = os.path.basename(path)
            for p in path_lst:
                new_path = os.path.join(path, p)
                if not new_path.endswith('.DS_Store'):  # file was getting added
                    # to list directory
                    file_system_tree = FileSystemTree(new_path)
                    current_subtrees.append(file_system_tree)
            AbstractTree.__init__(self, current_root, current_subtrees)

    def get_separator(self: AbstractTree) -> str:
        """Return the string used to separate nodes in the string
        representation of a path from the tree root to a leaf.

        Used by the treemap visualiser to generate a string displaying
        the items from the root of the tree to the currently selected leaf.
        """
        return os.path.sep


if __name__ == '__main__':
    import python_ta

    python_ta.check_all(
        config={
            'extra-imports': ['os', 'random', 'math'],
            'generated-members': 'pygame.*'})
